

<?php
    $cardClass = $class ?? 'card';
    $hasImage = isset($image) && $image;
?>

<div class="<?php echo e($cardClass); ?>">
    <?php if($hasImage): ?>
        <div class="card-image">
            <img src="<?php echo e($image); ?>" alt="<?php echo e($title ?? ''); ?>">
        </div>
    <?php endif; ?>
    
    <div class="card-content">
        <?php if(isset($badge)): ?>
            <span class="badge"><?php echo e($badge); ?></span>
        <?php endif; ?>
        
        <?php if(isset($title)): ?>
            <h3 class="card-title"><?php echo e($title); ?></h3>
        <?php endif; ?>
        
        <?php if(isset($content)): ?>
            <p class="card-text"><?php echo e($content); ?></p>
        <?php endif; ?>
        
        <?php if(isset($meta)): ?>
            <div class="card-meta">
                <?php echo e($meta); ?>

            </div>
        <?php endif; ?>
        
        <?php if(isset($tags)): ?>
            <div class="tech-stack">
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="badge badge-gray"><?php echo e($tag); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        
        <?php if(isset($link)): ?>
            <a href="<?php echo e($link); ?>" class="btn btn-secondary btn-sm mt-4">
                <?php echo e($linkText ?? 'Learn More'); ?>

            </a>
        <?php endif; ?>
        
        <?php echo e($slot ?? ''); ?>

    </div>
</div>
<?php /**PATH C:\laragon\www\personalspace\resources\views/components/card.blade.php ENDPATH**/ ?>