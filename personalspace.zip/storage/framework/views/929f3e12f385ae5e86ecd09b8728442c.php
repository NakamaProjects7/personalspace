

<?php $__env->startSection('title', 'Blog - Insights & Transformations'); ?>
<?php $__env->startSection('description', 'Latest thoughts, tutorials, and insights on Tech, Growth, and Cyber Security.'); ?>

<?php $__env->startSection('content'); ?>

<!-- Hero Section -->
<section class="hero" style="padding: 6rem 0 4rem;">
    <div class="container">
        <div class="text-center" style="max-width: 800px; margin: 0 auto;">
            <h1 class="fade-in-up">Blog & Newsletter</h1>
            <p class="hero-subtitle">Sharing real transformation journeys, technical deep-dives, and growth strategies</p>
        </div>
    </div>
</section>

<!-- Category Filter -->
<section style="padding: 2rem 0;">
    <div class="container">
        <div style="display: flex; justify-content: center; gap: 1rem; flex-wrap: wrap;">
            <button class="btn btn-primary btn-sm" data-filter="all">All Topics</button>
            <button class="btn btn-outline btn-sm" data-filter="tech">Tech</button>
            <button class="btn btn-outline btn-sm" data-filter="growth">Growth</button>
            <button class="btn btn-outline btn-sm" data-filter="security">Cyber Security</button>
        </div>
    </div>
</section>

<!-- Blog Posts Grid -->
<section class="section">
    <div class="container">
        <div class="grid grid-3">
            <?php
            $articles = [
                [
                    'title' => 'Building Secure Web Applications in 2026',
                    'content' => 'Explore the latest security trends and essential practices for modern web development. Learn how to stay ahead of threats.',
                    'image' => 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=400&h=300&fit=crop',
                    'badge' => 'Cyber Security',
                    'category' => 'security',
                    'meta' => '<span>5 min read</span> • <span>Feb 1, 2026</span>',
                    'link' => '/blog/detail'
                ],
                [
                    'title' => 'The Growth Mindset: Lessons from Startups',
                    'content' => 'How adopting a growth mindset can accelerate your career and help you navigate the ever-changing tech landscape.',
                    'image' => 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=400&h=300&fit=crop',
                    'badge' => 'Growth',
                    'category' => 'growth',
                    'meta' => '<span>8 min read</span> • <span>Jan 28, 2026</span>',
                    'link' => '/blog/detail'
                ],
                [
                    'title' => 'Modern Laravel Best Practices for Scalability',
                    'content' => 'Deep dive into architecting Laravel applications that can handle high traffic and complex business logic.',
                    'image' => 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=400&h=300&fit=crop',
                    'badge' => 'Tech',
                    'category' => 'tech',
                    'meta' => '<span>6 min read</span> • <span>Jan 25, 2026</span>',
                    'link' => '/blog/detail'
                ],
                [
                    'title' => 'Zero Trust Architecture: A Simple Guide',
                    'content' => 'Why traditional perimeter-based security is no longer enough and how Zero Trust can protect your infrastructure.',
                    'image' => 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=400&h=300&fit=crop',
                    'badge' => 'Cyber Security',
                    'category' => 'security',
                    'meta' => '<span>7 min read</span> • <span>Jan 20, 2026</span>',
                    'link' => '/blog/detail'
                ],
                [
                    'title' => 'Effective Communication for Tech Leaders',
                    'content' => 'Scaling your impact through leadership and communication. How to bridge the gap between business and tech.',
                    'image' => 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=300&fit=crop',
                    'badge' => 'Growth',
                    'category' => 'growth',
                    'meta' => '<span>10 min read</span> • <span>Jan 15, 2026</span>',
                    'link' => '/blog/detail'
                ],
                [
                    'title' => 'Microservices vs Monolith: Choosing the Right Path',
                    'content' => 'Analyzing when to stick with a monolith and when to transition to microservices for your startup.',
                    'image' => 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=400&h=300&fit=crop',
                    'badge' => 'Tech',
                    'category' => 'tech',
                    'meta' => '<span>12 min read</span> • <span>Jan 10, 2026</span>',
                    'link' => '/blog/detail'
                ]
            ];
            ?>
            
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div data-category="<?php echo e($article['category']); ?>">
                    <?php echo $__env->make('components.card', [
                        'title' => $article['title'],
                        'content' => $article['content'],
                        'image' => $article['image'],
                        'badge' => $article['badge'],
                        'meta' => $article['meta'],
                        'link' => $article['link'],
                        'linkText' => 'Read More',
                        'class' => 'blog-card'
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<!-- Newsletter Signup -->
<section class="section bg-gray">
    <div class="container">
        <div class="card card-lg card-highlight text-center" style="max-width: 800px; margin: 0 auto;">
            <h2>Join the Newsletter</h2>
            <p style="font-size: 1.125rem; margin-bottom: 2rem;">Get exclusive insights on tech, growth, and security directly in your inbox.</p>
            
            <form action="#" method="POST" data-validate style="max-width: 500px; margin: 0 auto;">
                <div class="form-group" style="display: flex; gap: 0.5rem;">
                    <input type="email" name="email" placeholder="Enter your email address" class="form-input" required style="margin: 0;">
                    <button type="submit" class="btn btn-primary">Subscribe</button>
                </div>
                <p class="text-xs text-gray mt-2">No spam. Only high-value content once a week.</p>
            </form>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\personalspace\resources\views/blog/index.blade.php ENDPATH**/ ?>