

<?php
    $variant = $variant ?? 'primary';
    $size = $size ?? '';
    $type = $type ?? 'link';
    
    $classes = 'btn btn-' . $variant;
    if ($size) {
        $classes .= ' btn-' . $size;
    }
    if (isset($class)) {
        $classes .= ' ' . $class;
    }
?>

<?php if($type === 'button'): ?>
    <button type="<?php echo e($buttonType ?? 'button'); ?>" class="<?php echo e($classes); ?>">
        <?php echo e($text ?? $slot); ?>

    </button>
<?php else: ?>
    <a href="<?php echo e($url ?? '#'); ?>" class="<?php echo e($classes); ?>">
        <?php echo e($text ?? $slot); ?>

    </a>
<?php endif; ?>
<?php /**PATH C:\laragon\www\personalspace\resources\views/components/button.blade.php ENDPATH**/ ?>